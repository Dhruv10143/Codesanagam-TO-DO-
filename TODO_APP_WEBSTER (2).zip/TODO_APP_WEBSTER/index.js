
const express = require('express');
const app = express();

const port = 8000;



const db = require('./config/mongoose');

const tasks = require('./models/task')

// the routes shouldn't be case sensitive 
app.set('case sensitive routing', false);
app.set('views', './views');
app.set('view engine', 'ejs');
app.use(express.urlencoded({ 'extended': true }));
app.use(express.static('assets'));

// homepage of our app
app.get('/', function (req, res)
{
    tasks.find({})
  .exec()
  .then(task => {
    
    var options = {
      title: "TODO List",
      task_list: task, 
    };

    
    res.render('to_do_list.ejs', options);
  })
  .catch(error => {
    console.log('There was an error in fetching the tasks from the database');
    return res.status(500).send('Internal Server Error');
  });

});


app.post('/create-task', function (req, res)
{
    tasks.create(req.body)
  .then(new_task => {
    console.log('Task created successfully:', new_task);

    
    return res.redirect('back');
  })
  .catch(error => {
    console.error('Error creating task:', error);
    return res.status(500).send('Internal Server Error');
  });
});





app.get('/delete-tasks/', function(req, res)
{
    let ids=new Array();
    for(let i in req.query)
    {
        ids.push(req.query[i]);
    }
    tasks.deleteMany({ _id: { $in: ids } })
  .then(() => {
    console.log('Tasks deleted successfully');

    return res.redirect('back');
  })
  .catch(error => {
    console.error('Error deleting tasks:', error);
    return res.status(500).send('Internal Server Error');
  });

});




app.listen(port, (error) =>
{
    
    if (error)
    {
        console.log('There was an error in starting the server');
        return;
    }
   
        console.log(`Server is running at port ${port}`);
});