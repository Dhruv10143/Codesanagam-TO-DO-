
const mongoose=require('mongoose');

mongoose.connect('mongodb+srv://krishnendu:ktyyg4UuOxRmW7Xv@cluster0.37roixz.mongodb.net/?retryWrites=true&w=majority', {useNewUrlParser: true, useUnifiedTopology: true });

//we'll use db for all further operations
const db=mongoose.connection;

//message on status of connection
db.on('error', console.error.bind(console, 'Error in connecting to the database!'));

db.once('open', function()
{
    console.log('Successfully connected to the database!');
});



